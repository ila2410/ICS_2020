import pygame
import random





class ics_memory():



    #Init-function to control the game by calling all functions and initialize variables that are needed in several different places, initialize the game and run the mainloop-function
    def __init__(self):

        #Before the game starts: Terminal inputs by the plyers for how many people are playing, what their names are and what difficulty they want
        self.playercount = self.get_player_number()
        self.player_names, self.player_points = self.get_names()
        self.difficulty = self.get_difficulty()

        
        #Start of the actual game; initialize pygame.
        pygame.init()


        #counter for how many cards have been clicked and hence are open to the player
        self.showcounter = 0

        #list to store cards' ID and location in solution
        self.opened_IDs = []
        
        #variable for who's self.turn it is
        self.turn = 0


        #Call of functions for text, game window, emoji-images (faces and backside) and the solution of the game (where each emoji-face is)
        self.fontsize, self.fontcolor, self.font, self.linegap = self.text()
        self.window, self.gap, self.chin, self.imagesize, self.windowX = self.game_window()
        self.backside, self.emojis = self.images()
        self.solution = self.cardplacement()

        #Call of function with mainloop which runs continuously until the player closes the window and the game stops
        self.mainloop()

        


    #function to get user input for the number of players (returns number of players)
    def get_player_number(self):
        
        playercount = ""

        #try to get an int from the user as the playercount. Ask again if input is not an int as there can be no half or negative players
        while type(playercount) != int:

            try:
                playercount = int(input("How many players are going to play? "))

                if playercount < 1:
                    playercount = ""
                    print("Please enter a natural number (integer above zero).")

            except:
                print("Your input can not be recognized as a number. Please enter a natural number (integer above zero).")
        

        return playercount




    #function to get input for names of the players (returns player names)
    def get_names(self):
    
        self.player_names = []
        self.player_points = []

        upcounter = 1
        points = 0

        #iterate through each player to get everyone's names
        while upcounter <= self.playercount:
            playername = input("Please enter a name for the player number {}, or press enter to use a generic name ".format(upcounter))

            #save name of each player or generate generic name if there is no input
            if playername == "":
                self.player_names.append("Player " + str(upcounter))

            else:
                self.player_names.append(playername)

            self.player_points.append(points)

            upcounter += 1
        

        return self.player_names, self.player_points




    #function to get player input for the difficulty, hence the number of pairs to be found (returns difficulty)
    #difficulty level can be an even number from 2 to 10 for a field of 2x2 up to 10x10
    def get_difficulty(self):

        self.difficulty = ""

        #try to get an even number between 2 and 10 from the player so that in the game, every emoji can be in the game exactly two times
        while type(self.difficulty) != int:

            try:
                self.difficulty = int(input("Please enter an even number from 2 (2x2) to 10 (10x10) for the difficulty-level. "))
            
                if not self.difficulty % 2 and 1 < self.difficulty < 11:
                    print("Thank you! Enjoy your game!")

                #Feedback for several kinds of mistakes; some can appear at the same time in which case both suggestions are printed
                else:

                    if self.difficulty % 2:
                        print("The level must be an even number.")

                    if self.difficulty < 2:
                        print("The level cannot be lower than 2.")

                    if self.difficulty > 10:
                        print("The level cannot be higher than 10.")
                
                    self.difficulty = ""

            #Feedback for other mistakes, if the input is not an int at all
            except:
                print("Your input cannot be identified as a valid difficulty-level.")
                self.difficulty = ""


        return self.difficulty




    #function to set up text displayed in the game window
    def text(self):

        #fontsize needs to be smaller for the easiest difficulty in order to be able to fit long player names (within limits) into the game window
        if self.difficulty == 2:
            self.fontsize = 25

        else:
            self.fontsize = 30
        
        #fontcolor in RGB: white = 255, 255, 255
        self.fontcolor = (255, 255, 255)

        #load font from font-file in the same folder as this game
        self.font = pygame.font.Font('Heathergreen.ttf', self.fontsize)

        #gap between the lines of text
        self.linegap = 5


        return self.fontsize, self.fontcolor, self.font, self.linegap




    #function to define the game window size, bezels and size of emoji-images
    def game_window(self):

        #pixel count of self.emojis in x- and y-direction
        self.imagesize = 80

        #desired gap between first and last column and row to the edge of the game window, last row and the bottom of the window as well as between each emoji
        self.gap = 10

        #desirded border between first row of emojis and top of the window
        self.chin = 3* (self.fontsize + 2* self.linegap)

        #calculate appropriate height and width for the game window according to selected difficulty
        self.windowX = self.difficulty * self.imagesize + (self.difficulty + 1) * self.gap
        windowY = self.difficulty * self.imagesize + (self.difficulty + 1) * self.gap + self.chin - self.gap

        #open game window
        self.window = pygame.display.set_mode((self.windowX, windowY))

        #set caption of window
        pygame.display.set_caption("ICS-Memory")


        return self.window, self.gap, self.chin, self.imagesize, self.windowX




    #function to load images (each image is 80x80 pixels) into a list called 'emojis', taking into account the selected difficulty
    def images(self):
        
        #load image for backside of emojis
        self.backside = pygame.image.load('0.png')
        
        #list for all other emojis
        self.emojis = []
        
        #counter for the while-loop below
        piccounter = 1

        #indicator to be stored with each emoji (important later when each image needs to be assigned two different locations within the game window so that every emoji has an identical patner)
        previously_selected = False

        #load as many images as necessary for the selected difficulty
        while piccounter < 1 + self.difficulty**2 / 2:

            #for each emoji-tile (card), an image, an indicator if the card has already been selected before as well as an ID is stored
            self.emojis.append([pygame.image.load(str(piccounter) + '.png'), previously_selected, piccounter])
            
            piccounter += 1


        return self.backside, self.emojis




    #function to define the position of all cards
    def cardplacement(self):

        #initial x- and y-coordinates
        x = self.gap
        y = self.chin
        
        #bool to indicate if card is visible to the player
        shown = False
        
        #list to store the solution to the game
        self.solution = []
        
        #loop to take each image from the emojis-list and assign two locations on screen so that the player(s) can find pairs
        while len(self.emojis) > 0:

            #select random card
            selected_card_id = random.randint(0, len(self.emojis)-1)
            selected_card = self.emojis[selected_card_id]

            #store solution of the game in solution-list: card image, card location, if it is currently being shown on screen, which emoji it is (unique ID-number)
            self.solution.append([selected_card[0], (x, y), shown, selected_card[2]])

            #increase x to the next spot in the same row
            x += self.imagesize + self.gap

            #if the end of the row has been reached, reset x and set y to the next row
            if x > (self.windowX - self.imagesize - self.gap):
                x = self.gap
                y += self.imagesize + self.gap

            #each card needs to be in the game twice. If it has just been added for the second time, it can be removed from the emojis-list
            if selected_card[1] == True:
                del self.emojis[selected_card_id]

            #if the current card has only been added once so far, this is indicated by setting previously_selected for this card to True
            else:
                self.emojis[selected_card_id][1] = True


        return self.solution




    #function to refresh what is shown on screen
    def redrawgamewindow(self, line1, line2, line3):

        #background color
        self.window.fill((110, 0, 0))

        #show "back sides" of all cards on screen
        for card1 in self.solution:
            self.window.blit(self.backside, card1[1])

            #check if card has been clicked on
            if card1[2] == True:

                #if so, show card on screen
                self.window.blit(card1[0], card1[1])

        #display text in the game window:
        #render 3 lines of text
        window_line1 = self.font.render(line1, True, self.fontcolor)
        window_line2 = self.font.render(line2, True, self.fontcolor)
        window_line3 = self.font.render(line3, True, self.fontcolor)

        #show each line in its respective location
        self.window.blit(window_line1, (10, self.linegap))
        self.window.blit(window_line2, (10, self.fontsize + 2* self.linegap))
        self.window.blit(window_line3, (10, 2 * self.fontsize + 3* self.linegap))


        #update the display so that all of the content of this function is being displayed
        pygame.display.update()




    #function with the main loop which keeps runnign while the game is being played
    def mainloop(self):
    
        #bool to define if game is running
        run = True

        #mainloop
        while run:

            #hide cards and reset showcounter after a while, delete correct matches:
            #if two cards are being displayed
            if self.showcounter == 2:

                #give the player time to inspect the selected cards
                pygame.time.delay(1200)


                #if the selected cards are a match
                if self.opened_IDs[0][0] == self.opened_IDs[1][0]:

                    #give a point to current player
                    self.player_points[self.turn] += 1
                
                    #both cards need to be deleted
                    #delete one card first
                    del self.solution[self.opened_IDs[0][1]]

                    #check if deleted card shifts the index of the other card that needs to be deleted and act accordingly
                    if self.opened_IDs[0][1] > self.opened_IDs[1][1]:
                        del self.solution[self.opened_IDs[1][1]]

                    else:
                        del self.solution[self.opened_IDs[1][1] - 1]

                #if the selected cards are no match, they need to be hidden again and it is the next player's turn
                else:

                    #counter to cycle through the solution-list
                    counter = 0

                    #cycle through solution list and set all cards to not shown (i.e. hidden)
                    while counter < len(self.solution):
                        self.solution[counter][2] = False
                        counter += 1

                    #next player's turn:
                    #if the last player was the last in the list of all players, it is the turn of the first one in the list
                    if self.turn == len(self.player_names) - 1:
                        self.turn = 0

                    #otherwise, it is the next one in the list
                    else:
                        self.turn += 1

                #reset counter for how many cards have been clicked
                self.showcounter = 0

                #reset list to store cards' ID and location in solution
                self.opened_IDs = []



            #check for mouse clicks on the close-button or within the window
            for event in pygame.event.get():
            
                #if the game window is closed, the program quits
                if event.type == pygame.QUIT:
                        run = False
            
                #otherwise, check if mouse button is pressed
                elif event.type == pygame.MOUSEBUTTONDOWN:

                    #check that no more than 2 cards are selected at a time
                    if self.showcounter < 2:

                        #store x- and y-coordinates of mouse
                        mouseX, mouseY = pygame.mouse.get_pos()
                    
                        #counter for loop below
                        solutioncounter = 0

                        #loop through all spots in solution to find the card that is being clicked on
                        while solutioncounter < len(self.solution):

                            #if mouse has been pressed on an emoji
                            if self.solution[solutioncounter][1][0] < mouseX < self.solution[solutioncounter][1][0] + 80 and self.solution[solutioncounter][1][1] < mouseY < self.solution[solutioncounter][1][1] + 80:
                            
                                #set shown for the respective card to true
                                self.solution[solutioncounter][2] = True

                                #add current card to the list of opened cards
                                self.opened_IDs.append([self.solution[solutioncounter][3], solutioncounter])
                            
                                #add to the counter to indicate how many cards are visible
                                self.showcounter += 1

                            solutioncounter += 1



            #if all matches have been found
            if len(self.solution) == 0:

                #The winner needs to be determined:
                #counter of players
                playercounter = 0

                #variable for storing winning points
                winning_points = 0

                #cycle through all players
                while playercounter < len(self.player_names):

                    #check if current player has more points than the previously detected player with the most points
                    if self.player_points[playercounter] > winning_points:

                        #if so, the current player has the most points of all players in the list so far and hence would be the winner if the occasion is not repeated in a later iteration of the loop
                        winning_points = self.player_points[playercounter]
                        winning_player = self.player_names[playercounter]
                        
                    playercounter += 1

                #reset playercounter
                playercounter = 0

                #set up a list for all winners
                draw = []

                #detect a potential draw between multiple players
                while playercounter < len(self.player_names):

                    if self.player_points[playercounter] == winning_points:
                        draw.append(playercounter)

                    playercounter += 1
            
                #announce winner(s)
                #if there is one winner:
                if len(draw) < 2:

                    #announce winner
                    message1 = "The winner is: {}".format(winning_player)
                    message2 = "with {} points!".format(winning_points)

                    #if there is just one player, they obviously win; hence they do not get congratulations ;P
                    if self.playercount == 1:
                        message3 = "duh"

                    #otherwise, winning is an achievement and
                    else:
                        message3 = "Congratulations!"

                #if there are multiple winners:
                else:

                    #new variable to collect names of all winners
                    winners = ""
                
                    #collect all winning player names into the "winners"-string
                    while len(draw) > 0:
                        winners = winners + self.player_names[draw[0]] + ", "
                        del draw[0]
                
                    #announce winners
                    message1 = "It's a draw! The winners are"
                    message2 = winners
                    message3 = "with {} points each!".format(winning_points)

            #if not all matches have been found yet
            else:

                #announce who's turn it is
                message1 = "It is {}'s turn.".format(self.player_names[self.turn])
                message2 = "They have {} points!".format(self.player_points[self.turn])
                message3 = "Good luck!"

            #refresh what's on screen by calling the respective function
            self.redrawgamewindow(message1, message2, message3)



        #when mainloop is exited, the game closes
        pygame.quit

    



#call the class in which the game is contained so that the code is run
game = ics_memory()
0577620_Final Project:
LCS-Memory

Creator: Lukas Emilius
student number: 0577620



Welcome to my project!
It is a memory-game with emojis.

It has multiplayer and variable difficulty via an adjustable amount of emojis.
It also announces who the winner is when the game is over.

To run it, you need a PC with python and pygame installed.
The font for displayed text, all required images as well as the module with the game-code itself are contained in the folder with my project.

When starting the game, you will be asked to enter a few details to set up your game.
After that, the game starts and the terminal sais "Enjoy your game".
The game-window might open in the background, but you can just switch to it via your systems' taskbar.
You can quit any time by closing the game window.
This will automatically also stop the code from running.

This is my first fully self made program, and I put a lot of work and dedication into it.
I hope you like it!